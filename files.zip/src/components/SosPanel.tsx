import React, { useEffect, useRef, useState } from "react";
import stations from "../data/stations.json";
import { db, storage } from "../firebase";
import {
  collection,
  addDoc,
  doc,
  updateDoc,
  serverTimestamp
} from "firebase/firestore";
import { ref as storageRef, uploadBytes, getDownloadURL } from "firebase/storage";

type Station = {
  id: string;
  name: string;
  phone?: string;
  lat: number;
  lng: number;
};

function haversine(lat1: number, lon1: number, lat2: number, lon2: number) {
  const toRad = (v: number) => (v * Math.PI) / 180;
  const R = 6371; // km
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export default function SosPanel() {
  const [status, setStatus] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [alarmOn, setAlarmOn] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscRef = useRef<OscillatorNode | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const [recording, setRecording] = useState(false);
  const parents = useRef<string[]>(["+911234000111", "+911234000222"]); // Replace with actual parent numbers or allow user management

  useEffect(() => {
    return () => {
      stopAlarm();
      stopRecording();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function startAlarm() {
    try {
      if (!audioCtxRef.current) audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      const ctx = audioCtxRef.current!;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = 1000;
      gain.gain.value = 0.001;
      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      // ramp up volume quickly
      gain.gain.exponentialRampToValueAtTime(0.6, ctx.currentTime + 0.6);
      oscRef.current = osc;
      setAlarmOn(true);
    } catch (e) {
      console.warn("Alarm start failed:", e);
      setStatus("Unable to play alarm (browser restriction).");
    }
  }

  function stopAlarm() {
    try {
      if (oscRef.current) {
        const oscillator = oscRef.current;
        const ctx = audioCtxRef.current!;
        // ramp down
        const gains = (oscillator as any).gain;
        oscillator.stop();
        oscRef.current = null;
        setAlarmOn(false);
      }
    } catch (e) {
      // ignore
      oscRef.current = null;
      setAlarmOn(false);
    }
  }

  async function startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const options: MediaRecorderOptions = {};
      // some browsers prefer specific mimeType; we'll let it choose
      const mr = new MediaRecorder(stream, options);
      mediaRecorderRef.current = mr;
      recordedChunksRef.current = [];
      mr.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) {
          recordedChunksRef.current.push(ev.data);
        }
      };
      mr.onstop = () => {
        // stop tracks
        stream.getTracks().forEach((t) => t.stop());
        setRecording(false);
      };
      mr.start(1000); // timeslice for dataavailable chunks
      setRecording(true);
      setStatus("Recording voice...");
    } catch (err) {
      console.error("Record error", err);
      setStatus("Microphone access denied or not available.");
    }
  }

  function stopRecording() {
    const mr = mediaRecorderRef.current;
    if (mr && mr.state !== "inactive") {
      mr.stop();
    }
    mediaRecorderRef.current = null;
    setRecording(false);
  }

  async function uploadRecordingAndGetUrl(alertId: string) {
    const chunks = recordedChunksRef.current;
    if (!chunks || chunks.length === 0) return null;
    const blob = new Blob(chunks, { type: "audio/webm" });
    try {
      const path = `recordings/${alertId}_${Date.now()}.webm`;
      const r = storageRef(storage, path);
      await uploadBytes(r, blob);
      const url = await getDownloadURL(r);
      return url;
    } catch (e) {
      console.error("Upload failed:", e);
      return null;
    }
  }

  async function sendAlertToFirestore(payload: any) {
    const alertsCol = collection(db, "alerts");
    const docRef = await addDoc(alertsCol, payload);
    return docRef.id;
  }

  function findNearestStation(lat: number, lng: number): Station | null {
    if (!stations || stations.length === 0) return null;
    let best: Station | null = null;
    let bestD = Infinity;
    (stations as Station[]).forEach((s) => {
      const d = haversine(lat, lng, s.lat, s.lng);
      if (d < bestD) {
        bestD = d;
        best = s;
      }
    });
    return best;
  }

  async function attemptCall(number?: string) {
    if (!number) return;
    try {
      // opening tel: link - user gesture required. Will open dialer on mobile.
      window.location.href = `tel:${number}`;
    } catch (e) {
      console.warn("Call failed", e);
    }
  }

  async function handleSosClick() {
    if (!navigator.geolocation) {
      setStatus("Geolocation not supported.");
      return;
    }
    setBusy(true);
    setStatus("Acquiring location...");
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        setStatus(`Location acquired (${lat.toFixed(5)}, ${lng.toFixed(5)})`);
        const nearest = findNearestStation(lat, lng);
        const stationName = nearest ? nearest.name : "No station found";
        const stationPhone = nearest?.phone;
        const confirmed = window.confirm(
          `Send SOS?\nLocation: ${lat.toFixed(5)}, ${lng.toFixed(5)}\nNearest: ${stationName}`
        );
        if (!confirmed) {
          setStatus("SOS cancelled.");
          setBusy(false);
          return;
        }

        // Start alarm and recording
        startAlarm();
        await startRecording();

        setStatus("Sending alert...");

        try {
          // create alert object
          const payload: any = {
            type: "SOS",
            timestamp: serverTimestamp(),
            location: { lat, lng },
            nearestStation: nearest ? { id: nearest.id, name: nearest.name, phone: nearest.phone } : null,
            user: {
              id: "anonymous",
              // add more user metadata if available (phone, name)
            },
            status: "triggered"
          };

          const alertId = await sendAlertToFirestore(payload);
          setStatus("Alert created. Recording will be uploaded.");

          // stop recording after a short delay to capture some audio
          setTimeout(async () => {
            stopRecording();
            // wait for recorder to finalize
            setTimeout(async () => {
              const recordingUrl = await uploadRecordingAndGetUrl(alertId);
              if (recordingUrl) {
                const alertDoc = doc(db, "alerts", alertId);
                await updateDoc(alertDoc, { recordingUrl });
                setStatus("Recording uploaded and alert updated.");
              } else {
                setStatus("No recording uploaded.");
              }
            }, 800);
          }, 8000); // record ~8 seconds of live audio, adjust as needed

          // Try to call parents (open dialer). We open first parent.
          const parentNumber = parents.current.length > 0 ? parents.current[0] : null;
          if (parentNumber) {
            setStatus((s) => (s ? s + " Calling parent..." : "Calling parent..."));
            // small timeout to ensure user sees UI update
            setTimeout(() => attemptCall(parentNumber), 600);
          }

          // Optionally, open call to station
          if (stationPhone) {
            // We avoid opening two tel: links immediately, but we can ask user to call station:
            const callStation = window.confirm(`Also call nearest station (${stationName}) now?`);
            if (callStation) {
              attemptCall(stationPhone);
            }
          }
        } catch (e) {
          console.error("Alert send failed", e);
          setStatus("Failed to send alert.");
        } finally {
          setBusy(false);
        }
      },
      (err) => {
        console.error(err);
        setStatus("Unable to acquire location. Check permissions.");
        setBusy(false);
      },
      { enableHighAccuracy: true, timeout: 15000 }
    );
  }

  return (
    <div>
      <button
        className="sosButton"
        onClick={handleSosClick}
        disabled={busy}
        aria-label="Send SOS"
        title="Send SOS"
      >
        {busy ? "Processing..." : "SOS — Send Location & Voice"}
      </button>

      <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
        <button
          className="btn"
          onClick={() => {
            if (alarmOn) {
              stopAlarm();
            } else {
              startAlarm();
            }
          }}
        >
          {alarmOn ? "Stop Alarm" : "Test Alarm"}
        </button>

        <button
          className="btn"
          onClick={() => {
            if (recording) {
              stopRecording();
            } else {
              startRecording();
            }
          }}
        >
          {recording ? "Stop Recording" : "Start Recording"}
        </button>
      </div>

      <div className="status">{status}</div>
    </div>
  );
}