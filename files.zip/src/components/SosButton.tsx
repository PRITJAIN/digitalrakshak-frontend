import React, { useState } from "react";

type AlertResponse = {
  success: boolean;
  id?: string;
  message?: string;
};

export default function SosButton() {
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<string | null>(null);

  async function sendAlert(lat: number, lng: number) {
    setLoading(true);
    setStatus("Sending alert...");
    try {
      const resp = await fetch("/api/alerts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "SOS",
          timestamp: new Date().toISOString(),
          location: { lat, lng },
          // you can include user metadata here (id, name, phone) if available
        }),
      });
      const data: AlertResponse = await resp.json();
      if (data.success) {
        setStatus("Alert sent successfully.");
      } else {
        setStatus(data.message || "Failed to send alert.");
      }
    } catch (err) {
      console.error(err);
      setStatus("Network error while sending alert.");
    } finally {
      setLoading(false);
    }
  }

  function handleSosClick() {
    if (!navigator.geolocation) {
      setStatus("Geolocation is not supported by your browser.");
      return;
    }

    setStatus("Acquiring location...");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        // confirm with the user before sending
        const confirmed = window.confirm(
          `Send SOS with your location?\nLatitude: ${latitude.toFixed(
            5
          )}\nLongitude: ${longitude.toFixed(5)}`
        );
        if (confirmed) {
          sendAlert(latitude, longitude);
        } else {
          setStatus("SOS cancelled.");
        }
      },
      (err) => {
        console.error(err);
        setStatus("Unable to get location. Please check permissions.");
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }

  return (
    <div className="sos-wrapper">
      <button
        onClick={handleSosClick}
        disabled={loading}
        style={{
          background: "radial-gradient(circle at 30% 20%, #ff5f6d, #ff0000)",
          color: "white",
          border: "none",
          padding: "1rem 1.5rem",
          borderRadius: 12,
          fontSize: "1.2rem",
          cursor: loading ? "wait" : "pointer",
          boxShadow: "0 6px 18px rgba(255,0,0,0.25)",
        }}
        aria-label="Send SOS"
        title="Send SOS"
      >
        {loading ? "Sending..." : "SOS"}
      </button>

      {status && (
        <div style={{ marginTop: 12, color: "#333", fontSize: 14 }}>{status}</div>
      )}
    </div>
  );
}