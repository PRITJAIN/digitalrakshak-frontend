import React from "react";
import SosPanel from "./components/SosPanel";

export default function App() {
  return (
    <div className="app">
      <div className="card" role="main">
        <div className="header">
          <div>
            <div className="title">DigitalRakshak</div>
            <div className="subtitle">Quick SOS, auto location & voice recording</div>
          </div>
        </div>

        <SosPanel />
        <div style={{ marginTop: 14 }} className="small">
          Tip: For best results test on a mobile device. Allow location and microphone.
        </div>
      </div>
    </div>
  );
}